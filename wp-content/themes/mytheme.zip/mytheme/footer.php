<hr>

      <footer>
        <p><?php bloginfo('name'); ?></p>
      </footer>
<?php if(!is_front_page()):?>
    </div> <!-- /container -->
<?php endif;?>
    <?php wp_footer(); ?>

  </body>
</html>